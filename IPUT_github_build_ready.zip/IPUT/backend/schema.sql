CREATE TABLE devices (
  id BIGSERIAL PRIMARY KEY,
  owner_id TEXT NOT NULL,
  device_name TEXT NOT NULL,
  device_token_hash TEXT UNIQUE NOT NULL,
  sharing_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE locations (
  id BIGSERIAL PRIMARY KEY,
  device_id BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  latitude DOUBLE PRECISION NOT NULL CHECK(latitude BETWEEN -90 AND 90),
  longitude DOUBLE PRECISION NOT NULL CHECK(longitude BETWEEN -180 AND 180),
  accuracy REAL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX locations_device_time ON locations(device_id, recorded_at DESC);
