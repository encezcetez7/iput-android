require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const crypto = require("crypto");
const { Pool } = require("pg");

const app = express();
const db = new Pool({ connectionString: process.env.DATABASE_URL });
app.use(helmet());
app.use(cors({ origin: process.env.DASHBOARD_ORIGIN || false }));
app.use(express.json({ limit: "32kb" }));

const hash = value => crypto.createHash("sha256").update(value).digest("hex");

// Device token is unique per paired device. Pairing/account endpoints are intentionally
// omitted from this starter; implement them with verified account sessions before production.
app.post("/api/location", async (req, res) => {
  const auth = req.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Unauthorized" });

  const { latitude, longitude, accuracy } = req.body || {};
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude) ||
      latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    return res.status(400).json({ error: "Invalid coordinates" });
  }

  try {
    const device = await db.query(
      "SELECT id FROM devices WHERE device_token_hash=$1 AND sharing_enabled=TRUE",
      [hash(token)]
    );
    if (!device.rowCount) return res.status(403).json({ error: "Sharing not enabled or device not paired" });
    await db.query(
      "INSERT INTO locations(device_id,latitude,longitude,accuracy) VALUES($1,$2,$3,$4)",
      [device.rows[0].id, latitude, longitude, accuracy ?? null]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server error" });
  }
});

// Development-only endpoint: protect with real account sessions and owner-level authorization.
app.get("/api/devices/latest", async (req, res) => {
  if (!process.env.ADMIN_TOKEN ||
      req.get("authorization") !== `Bearer ${process.env.ADMIN_TOKEN}`) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const result = await db.query(`
    SELECT DISTINCT ON (d.id) d.id, d.device_name, d.sharing_enabled,
      l.latitude, l.longitude, l.accuracy, l.recorded_at
    FROM devices d LEFT JOIN locations l ON l.device_id=d.id
    ORDER BY d.id, l.recorded_at DESC
  `);
  res.json(result.rows);
});

app.listen(process.env.PORT || 3000, () => console.log("IPUT API listening"));
