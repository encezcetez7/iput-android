# Build APK lewat GitHub Actions

1. Buat repository baru di GitHub, misalnya `iput-android`.
2. Upload seluruh isi folder proyek ini ke branch `main` (pastikan `.github/workflows/android-build.yml` ikut terunggah).
3. Buka tab **Actions** pada repository. Aktifkan Actions bila diminta.
4. Workflow **Build IPUT Android APK** akan berjalan setelah push. Bisa juga pilih workflow lalu klik **Run workflow**.
5. Tunggu job hijau. Buka run terbaru → bagian **Artifacts** → unduh `iput-debug-apk.zip`.
6. Ekstrak ZIP dan instal `app-debug.apk` pada perangkat Android untuk pengujian.

Konfigurasi Android:
- minSdk 29 (Android 10)
- compileSdk 36
- targetSdk 36 (Android 16)

Catatan:
- Workflow ini menghasilkan APK debug untuk uji coba, bukan rilis Play Store.
- Build yang sukses tidak berarti semua fitur server telah aktif. Endpoint upload lokasi masih perlu implementasi setelah pairing/authentication aman tersedia.
- Jangan memasang aplikasi pada perangkat orang lain tanpa persetujuan. Berbagi lokasi harus tampak jelas dan dapat dihentikan oleh pemilik perangkat.
