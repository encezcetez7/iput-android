import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import "./style.css";

export default function App() {
  const [devices, setDevices] = useState([]);
  const [error, setError] = useState("");
  async function refresh() {
    try {
      // Configure a same-origin authenticated backend proxy. Do not embed admin tokens here.
      const r = await fetch("/api/devices/latest", { credentials: "include" });
      if (!r.ok) throw new Error("Silakan login atau periksa koneksi server.");
      setDevices(await r.json()); setError("");
    } catch (e) { setError(e.message); }
  }
  useEffect(() => {
    refresh();
    const timer = setInterval(refresh, 10000);
    return () => clearInterval(timer);
  }, []);
  const located = devices.filter(d => d.latitude != null && d.longitude != null);
  return <main>
    <header><div><h1>IPUT</h1><p>Dashboard berbagi lokasi</p></div>
      <span>{located.length} perangkat memiliki lokasi</span></header>
    {error && <p className="notice">{error}</p>}
    <section className="map">
      <MapContainer center={[-6.2,106.816]} zoom={11} style={{height:"100%",width:"100%"}}>
        <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
        {located.map(d => <Marker key={d.id} position={[Number(d.latitude),Number(d.longitude)]}>
          <Popup><b>{d.device_name}</b><br/>Akurasi: {d.accuracy ?? "—"} m<br/>Update: {d.recorded_at}</Popup>
        </Marker>)}
      </MapContainer>
    </section>
    <h2>Perangkat yang dibagikan</h2>
    {devices.map(d => <article key={d.id}><b>{d.device_name}</b><span>{d.latitude == null ? "Belum ada lokasi" : "Lokasi tersedia"}</span></article>)}
  </main>;
}
