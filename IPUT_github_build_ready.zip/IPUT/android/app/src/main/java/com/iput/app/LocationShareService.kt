package com.iput.app

import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*

class LocationShareService : Service() {
    private lateinit var client: FusedLocationProviderClient
    private lateinit var callback: LocationCallback

    override fun onCreate() {
        super.onCreate()
        val channelId = "iput_location_sharing"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId, "Berbagi lokasi IPUT",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("IPUT — berbagi lokasi aktif")
            .setContentText("Lokasi perangkat sedang dibagikan. Buka IPUT untuk menghentikan.")
            .setOngoing(true)
            .build()
        startForeground(41, notification)

        client = LocationServices.getFusedLocationProviderClient(this)
        val fine = ContextCompat.checkSelfPermission(this,
            android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this,
            android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) { stopSelf(); return }

        val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 30_000L)
            .setMinUpdateIntervalMillis(15_000L).build()

        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                // TODO: send to authenticated API over HTTPS after device pairing.
                // Never upload location until the account owner has explicitly enabled sharing.
            }
        }
        client.requestLocationUpdates(request, callback, Looper.getMainLooper())
    }

    override fun onDestroy() {
        if (::client.isInitialized && ::callback.isInitialized) client.removeLocationUpdates(callback)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
