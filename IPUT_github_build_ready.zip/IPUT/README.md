# IPUT — starter project

IPUT is a transparent family/partner sharing app starter:
- The home screen contains a playable Tetris-style mini game.
- Camera opens only after the user taps the camera button and uses Android's camera app.
- Gallery uses Android Photo Picker; the user chooses each photo.
- Location sharing starts only after the user enables it and grants Android location permission. A persistent foreground notification indicates sharing is active.
- Dashboard shows only devices whose users have explicitly paired and shared their location.

## Project layout
- `android/` — Kotlin + Jetpack Compose Android app
- `backend/` — Express API starter
- `dashboard/` — React + Leaflet dashboard starter

## Important setup
1. Create a PostgreSQL database and apply `backend/schema.sql`.
2. Copy `backend/.env.example` to `backend/.env`; set a long random admin secret and database URL.
3. Run `npm install` and `npm start` inside `backend/`.
4. Configure the Android app's `API_BASE_URL` in `android/app/build.gradle.kts`.
5. Build with Android Studio (JDK 17, Android SDK 35).
6. Run the dashboard with `npm install` and `npm run dev` in `dashboard/`.

This is a starter codebase, not a production-ready service. Before deployment, add proper account registration, secure device pairing, per-user authorization, TLS, rate limiting, retention/deletion controls, and secret management. Do not put admin secrets in a browser bundle. The dashboard example intentionally uses a development-only server proxy pattern and must be replaced with a secure session-based backend in production.
