package com.iput.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var selectedPhoto by mutableStateOf<String?>(null)
    private val photoPicker = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> selectedPhoto = uri?.toString() }

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap -> /* User-triggered camera capture; preview is returned in memory. */ }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) startLocationSharing()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFDDA5FF),
                background = Color(0xFF160D24),
                surface = Color(0xFF251638)
            )) {
                IputHome(
                    onCamera = { cameraLauncher.launch(null) },
                    onGallery = {
                        photoPicker.launch(
                            PickVisualMediaRequest(
                                ActivityResultContracts.PickVisualMedia.ImageOnly
                            )
                        )
                    },
                    onLocationToggle = { enabled ->
                        if (enabled) {
                            val permissions = arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                            locationPermission.launch(permissions)
                        } else stopLocationSharing()
                    },
                    photoSelected = selectedPhoto != null
                )
            }
        }
    }

    private fun startLocationSharing() {
        val intent = Intent(this, LocationShareService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopLocationSharing() {
        stopService(Intent(this, LocationShareService::class.java))
    }
}

@Composable
fun IputHome(
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onLocationToggle: (Boolean) -> Unit,
    photoSelected: Boolean
) {
    var locationEnabled by remember { mutableStateOf(false) }
    var game by remember { mutableStateOf(TetrisState()) }

    Surface(Modifier.fillMaxSize(), color = Color(0xFF160D24)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("IPUT", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text("Mini Game", color = Color(0xFFDDA5FF))
            TetrisBoard(game = game, onMove = { game = game.move(it) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { game = game.rotate() }) { Text("Putar") }
                Button(onClick = { game = game.drop() }) { Text("Turun") }
                OutlinedButton(onClick = { game = TetrisState() }) { Text("Ulang") }
            }
            Divider(color = Color.DarkGray)
            Text("Fitur berbagi", color = Color.White, style = MaterialTheme.typography.titleMedium)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCamera, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(6.dp)); Text("Kamera")
                }
                OutlinedButton(onClick = onGallery, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Photo, null); Spacer(Modifier.width(6.dp)); Text("Galeri")
                }
            }
            if (photoSelected) Text("Foto telah dipilih.", color = Color(0xFFDDA5FF))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Berbagi lokasi", color = Color.White)
                    Text("Lokasi aktif ditampilkan melalui notifikasi.", color = Color.LightGray,
                        style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = locationEnabled,
                    onCheckedChange = {
                        locationEnabled = it
                        onLocationToggle(it)
                    }
                )
            }
        }
    }
}

@Composable
fun TetrisBoard(game: TetrisState, onMove: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        game.rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                row.forEach { filled ->
                    Box(
                        Modifier.weight(1f).aspectRatio(1f)
                            .background(if (filled) Color(0xFFB56CE8) else Color(0xFF342443),
                                RoundedCornerShape(3.dp))
                    )
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onMove("left") }) { Text("←") }
            Button(onClick = { onMove("right") }) { Text("→") }
        }
    }
}

// Compact playable starter board; extend with collision, line clearing and scoring.
data class TetrisState(val rows: List<List<Boolean>> = List(12) { List(8) { false } }) {
    fun move(direction: String) = this
    fun rotate() = this
    fun drop(): TetrisState {
        val next = rows.map { it.toMutableList() }.toMutableList()
        val row = next.indexOfFirst { line -> line.any { !it } }
        if (row >= 0) next[row][(System.currentTimeMillis() % 8).toInt()] = true
        return copy(rows = next)
    }
}
