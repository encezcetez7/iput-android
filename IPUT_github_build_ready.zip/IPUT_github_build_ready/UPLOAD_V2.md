IPUT updated build-ready archive

Upload this ZIP to the root of the GitHub repository using the same filename:
IPUT_github_build_ready.zip

The repository workflow is configured to extract this filename.
The Photo Picker request in MainActivity.kt has been corrected.
